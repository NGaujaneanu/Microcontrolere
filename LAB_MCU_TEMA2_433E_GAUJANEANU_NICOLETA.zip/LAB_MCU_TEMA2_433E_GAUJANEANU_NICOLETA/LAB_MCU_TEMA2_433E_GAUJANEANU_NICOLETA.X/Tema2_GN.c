/*
 * File:   Tema2_GN.c
 * Author: Nicoleta Gaujaneanu
 *
 * Created on December 20, 2022, 8:50 PM
 */


#pragma config FEXTOSC = OFF          // External Oscillator Selection (Oscillator not enabled)
#pragma config RSTOSC = HFINTOSC_1MHZ // Reset Oscillator Selection (HFINTOSC with HFFRQ = 4 MHz and CDIV = 4:1)
#pragma config WDTE = OFF             // WDT operating mode (WDT Disabled; SWDTEN is ignored)

#include <xc.h>

#define _XTAL_FREQ (1000000)

void main(void) {
    
    TRISD=0b00000000;      //configuram pinii RD6 si RD7 ca pini de iesire (0 logic), pinii neutilizati vor fi pini tot ca intrari
    LATD=0b10000000;       //prinim cu RD7 aprins si RD6 stins
	
    // initializare modul TIMER0
    PIR3bits.TMR0IF = 0;        // stergem flag indicator de depasire
    T0CON0bits.MD16 = 0b1;      // mod de operare pe 16 biti
    T0CON1bits.T0CKPS = 0b0101; // setam rata prescalerului la 1:64 - calcul pdf
    T0CON1bits.ASYNC = 0b0;     // TMR0 Input Asynchronization Enable bit The input to the TMR0 counter is synchronized to FOSC/4      
    T0CON1bits.CS = 0b010;      // Timer0 Clock Source Select bits FOSC/4
    TMR0H = 0;                  // se intitializeaza registrele de numarare cu valoarea zero
    TMR0L = 0;                  // cu scopul de a numara de la 0 spre 65535
    T0CON0bits.EN = 0b1;        // porneste modulul TIMER0, incepe numararea

    while (1) 
    {
        if(LATDbits.LATD6==0) //pentru RD6 stins
        {
           LATDbits.LATD7 = ~LATDbits.LATD7; //ledul asociat pinului RD7 isi schimba starea (RD7 devine stins)
           LATDbits.LATD6 = ~LATDbits.LATD6; //ledul asociat pinului RD7 isi schimba starea (RD6 devine aprins)
           // asteapta depasirea timer-ului, se creeaza intarzierea
           while (PIR3bits.TMR0IF == 0) {}
           // reinitializare modul TIMER0 - calcul pdf
           PIR3bits.TMR0IF = 0; // se reseteaza bitul indicator de depasire 
           TMR0H = 0x67; // se reinitializeaza registrele de numarare
           TMR0L = 0x6A;
        }
    else 
        if(LATDbits.LATD7==0) //pentru RD7 stins
        {
           LATDbits.LATD6 = ~LATDbits.LATD6;  //ledul asociat pinului RD6 isi schimba starea (RD6 devine stins)
           LATDbits.LATD7 = ~LATDbits.LATD7;  //ledul asociat pinului RD7 isi schimba starea (RD7 devine aprins)
           // asteapta depasirea timer-ului, se creeaza intarzierea
           while (PIR3bits.TMR0IF == 0) {}
           // reinitializare modul TIMER0
           PIR3bits.TMR0IF = 0; // se reseteaza bitul indicator de depasire
           TMR0H = 0x67; // se reinitializeaza registrele de numarare
           TMR0L = 0x6A;
        }
    }
}	
